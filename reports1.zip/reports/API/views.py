from django.shortcuts import render
from django.http import JsonResponse
from datetime import datetime, date as dt
from reports.forms import reportForm
# Create your views here.

def reportAPI(request):

    res = {'status' : 'error', 'msg':"Invalid Date", 'data':[]}
    
    sub = reportForm(request.POST)
    if sub.is_valid():
        try:
            date = request.POST['date']
            date_format = "%m/%d/%Y"
            a = datetime.strptime(date, date_format)
            b = datetime.strptime(dt.today().strftime('%m/%d/%Y'), date_format)
            delta = b - a
            if(delta.days > 28):
                res['status'] = "error"
                res['msg'] = "Date should no be more than 28 days"
            else:
                res['status'] = "ok"
                di = [
                    [ "Tiger Nixon","System Architect", "2 Jan 2019" ]

                ]

                res['data'] = di
        except:
            pass

    return JsonResponse(res)