from django import forms
from django.core.validators import RegexValidator

class reportForm(forms.Form):
    date = forms.DateField(widget=forms.TextInput(
        attrs={
        'autocomplete':'off',
        'id':'date',
        'data-provide':'datepicker',
        'class':'datepicker'
        }
    ),label='Date')
    